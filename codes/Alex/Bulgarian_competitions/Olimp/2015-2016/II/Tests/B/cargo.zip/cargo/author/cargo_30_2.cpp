// Author Pano Panov
#include <iostream>
//---------------------------------------------------------------------------------
// Обхождаме последователно периода на планиране, от първия до последния ден и
// избираме съгласно следното правило:
// Сред заявките, които са останали и които могат да бъдат изпълнени в текущия ден,
// избираме тази, чиито краен срок е най-ранен (най-близък).
// Това е оптималната стратегия.
//---------------------------------------------------------------------------------
using namespace std;
#define MAX_DAYS 124
int Days[MAX_DAYS][MAX_DAYS];
int Holidays[MAX_DAYS][MAX_DAYS];
int period; /* Брой дни - период на планиране */
int m;      /* Брой заявки                    */
int p;      /* Брой пилоти / екипажи          */
void initialize()
{
  int i,j;
  for( i = 0; i < MAX_DAYS; i++)
    for( j = i; j <  MAX_DAYS; j++)
    {
      Days[i][j] = 0;
      Holidays[i][j] = 0;
    }
}
void ReadData()
   {
    int i, from, until;
    cin >> period;
    cin >> m >> p;
    p=p/2;               // Брой екипажи
    for(i = 0; i < m; i++)
       {
        cin >> from >> until;
        Days[from-1][until-1]++;
        Holidays[from-1][until-1]++;
       }
   }
bool analyze(int pWeek[][MAX_DAYS], int weekends, int p, int m)
{
  int i,j,k,dpw; // weekends == 1 - допуска се работа през уикендите
  for(i=0; i < period; i++)
     {
      dpw = !weekends && (((i) % 7)>=5) ? 0 : p;
      // Най спешните заявки --> първо
      for(j = i; j < period && dpw; j++)
        for(k = 0; k <= i && dpw; k++)
           {

            if(pWeek[k][j])
              {
               if(pWeek[k][j] <= dpw)
                 {
                  dpw -= pWeek[k][j];
                  m -= pWeek[k][j];
                  pWeek[k][j] = 0;
                 }
               else
                 {
                  m -= dpw;
                  pWeek[k][j] -= dpw;
                  dpw = 0;
                 }
              }
           }
     }
  return ( m == 0 );
}
int main()
{
    initialize();
    ReadData();
    if(analyze(Days, 0, p, m)) cout << "OK" << endl;
    else
      {
       if(analyze(Holidays, 1, p, m)) cout << "MIXED" << endl;
       else cout << "IMPOSSIBLE" << endl;
      }
 return 0;
}
/* End of File */
