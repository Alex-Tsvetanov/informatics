#include<cstdio>
#include<algorithm>

using namespace std;

const int MAXN=1000002;
int s7[MAXN],s5[MAXN],e7[MAXN],e5[MAXN];

int main()
{
    int n, m, p;
    bool is_ok7=true, is_ok5=true;
    scanf("%d",&n);
    scanf("%d%d",&m,&p);
    p=p/2;
    for(int i=1; i<=m; i++)
    {
        int x, y;
        scanf("%d%d",&x,&y);
        s7[x]++;
        e7[y]++;
        int x1, y1;
        if((x-1)%7<5) x1=5*((x-1)/7)+x%7;
        else x1=5*((x-1)/7)+6;
        if((y-1)%7<5) y1=5*((y-1)/7)+y%7;
        else y1=5*((y-1)/7)+5;
        s5[x1]++;
        e5[y1]++;
        if (x1>y1) is_ok5=false;
    }
    int n1;
    if((n-1)%7<5) n1=5*((n-1)/7)+n%7;
        else n1=5*((n-1)/7)+5;
    
    int akt=0, z=0;
    for(int i=1; i<=n1 && is_ok5; i++)
    {
        akt+=s5[i];
        z=z+s5[i]-min(akt,p);
        z=max(0,z);
        akt-=e5[i];
        if(akt<z) is_ok5=false;  
    }
    if(is_ok5)
    {
        printf("OK\n");
        return 0;
    }
    akt=0, z=0;
    for(int i=1; i<=n && is_ok7; i++)
    {
        akt+=s7[i];
        z=z+s7[i]-min(akt,p);
        z=max(0,z);
        akt-=e7[i];
        if(akt<z) is_ok7=false;
    }
    if(is_ok7)
      printf("MIXED\n");
    else
      printf("IMPOSSIBLE\n");
    return 0;
}