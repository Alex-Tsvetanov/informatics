#include<cstdio>
#include<algorithm>
#include<utility>

using namespace std;

const int MAXM=1000002;
#define pp pair<int,int>

pp s7[2*MAXM],s5[2*MAXM];

int main()
{
    int n, m, p;
    bool is_ok7=true, is_ok5=true;
    scanf("%d",&n);
    scanf("%d%d",&m,&p);
    p=p/2;
    s7[2*m]=make_pair(n+1,1);
    s5[2*m]=make_pair(n+1,1);
    for(int i=0; i<m; i++)
    {
        int x, y;
        scanf("%d%d",&x,&y);
        s7[2*i]=make_pair(x,0);
        s7[2*i+1]=make_pair(y,1);
        int x1, y1;
        if((x-1)%7<5) x1=5*((x-1)/7)+x%7;
        else x1=5*((x-1)/7)+6;
        if((y-1)%7<5) y1=5*((y-1)/7)+y%7;
        else y1=5*((y-1)/7)+5;
        s5[2*i]=make_pair(x1,0);
        s5[2*i+1]=make_pair(y1,1);
        if (x1>y1) is_ok5=false;
    }
    m=2*m;
    sort(s7,s7+m);
    sort(s5,s5+m);
    
    int akt=0, z=0, old_val=0, new_val;
    int i=0;
    while(i<m && is_ok5)
    {
        new_val=s5[i].first;
        z=z-(new_val-old_val-1)*min(akt,p);
        z=max(0,z);
        int seg[2]={0,0};
        seg[s5[i].second]++;
        while(s5[i+1].first==new_val)
        {
            i++;
            seg[s5[i].second]++;
        }
        akt+=seg[0];
        z=z+seg[0]-min(akt,p);
        z=max(0,z);
        akt-=seg[1];
        if(akt<z) is_ok5=false;
        old_val=new_val;
        i++;   
    }
    if(is_ok5)
    {
        printf("OK\n");
        return 0;
    }
    akt=0; z=0; old_val=0;
    i=0;
    while(i<m && is_ok7)
    {
        new_val=s7[i].first;
        z=z-(new_val-old_val-1)*min(akt,p);
        z=max(0,z);
        int seg[2]={0,0};
        seg[s7[i].second]++;
        while(s7[i+1].first==new_val)
        {
            i++;
            seg[s7[i].second]++;
        }
        akt+=seg[0];
        z=z+seg[0]-min(akt,p);
        z=max(0,z);
        akt-=seg[1];
        if(akt<z) is_ok7=false;
        old_val=new_val;
        i++;    
    }
    if(is_ok7)
      printf("MIXED\n");
    else
      printf("IMPOSSIBLE\n");
    return 0;
}

/*
100
3 2
4 5
5 6
5 7
*/