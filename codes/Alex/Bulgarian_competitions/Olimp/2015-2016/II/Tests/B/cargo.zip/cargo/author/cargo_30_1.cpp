// Author Pano Panov
//--------------------------------------------------------------------------------
// Системата от линейни ограничения е удовлетворима ако и само ако
// не съществува период на доставка, в който броя на включените
// заявки за доставка е по-голям от капацитета на превозвача за съответния период.
//--------------------------------------------------------------------------------
#include <iostream>
using namespace std;
#define OK         0
#define MIXED      1
#define IMPOSSIBLE 2
#define MAX_DAYS  124
typedef struct {
 int size;
 int constraint[MAX_DAYS][MAX_DAYS];
 int period[MAX_DAYS][MAX_DAYS];
} timeInter;
timeInter Weeks;
int brdays;
void clean(timeInter *strus)
{
  int i,j;
  for(i = 0;i < strus->size; i++)
    for (j = 0;j < strus->size; j++){
      strus->constraint[i][j] = 0;
      strus->period[i][j] = 0;
    }
}
void calcsum(timeInter *strus)
{
  int i , j, sum;
  for(i = 0; i < strus->size; i++){
    sum = strus->period[i][i];
    for(j = i-1; j >= 0; j--){
      sum += strus->period[j][i];
      strus->period[j][i] = sum;
    }
  }
}

void calc_constraints(timeInter *strus)
{
  int i, j;
  for(i = 0;i < strus->size; i++)
    strus->constraint[i][i] = strus->period[i][i];
  for(i = 1; i < strus->size; i++)
    for(j = 0; j < strus->size-i; j++){
      strus->constraint[j][j+i] = strus->constraint[j][j+i-1] + strus->period[j][j+i];
    }
}

int solve(timeInter *theWeeks, int p)
{
  int i, j;
  int workingdays, weekend = 0;

  for(i = 0; i < theWeeks->size; i++){

    workingdays = 0;
    for(j = i; j >= 0; j--){
        workingdays += ((j % 7)<5);  // Check if non weekend day
        if(workingdays*p < theWeeks->constraint[j][i])
          {
           weekend = 1;
           if((i-j+1)*p < theWeeks->constraint[j][i])
             {
              return IMPOSSIBLE;
             }
          }
    }
  }
  if(weekend)
    {
     return MIXED;
    }
  else
    {
     return OK;
    }
}

int main()
{
  int j, m, pilots, crews, from, until, num;
  cin>>brdays;
  Weeks.size = brdays;

    clean(&Weeks);
    cin >> m >> pilots;
    crews = pilots / 2;      // Брой екипажи
    for (j = 0; j < m; j++){
      cin>>from>>until;
      Weeks.period[from-1][until-1]++;
    }
   calcsum(&Weeks);
   calc_constraints(&Weeks);
   num = solve(&Weeks, crews);
    switch (num)
    {
      case OK:
        cout<<"OK"<<endl;
        break;
      case MIXED:
        cout<<"MIXED"<<endl;
        break;
      case IMPOSSIBLE:
        cout<<"IMPOSSIBLE"<<endl;
        break;
    }
  return 0;
}
