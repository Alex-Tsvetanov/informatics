#include<cstdio>
#include<vector>
#include<queue>
using namespace std;

#define INT long long int

#define INF 200000000000000000
#define REV 1000000000
typedef pair<INT, INT> ii;
typedef vector<ii> vii;
#define TRvii(c, it) for (vii::iterator it = (c).begin(); it != (c).end(); it++)
vector<vii> AdjList;

int V, s, s_end;
INT m;

void input()
{
  scanf("%d%d%d",&V,&s,&s_end);
  for(int j=0;j<=V;j++) {vii temp; temp.clear(); AdjList.push_back(temp);}


  int v1,v2;
  INT w;
  w=1;
  while(!feof(stdin))
  {
    scanf("%d%d",&v1,&v2);
    AdjList[v1].push_back(ii(v2,w));
    AdjList[v2].push_back(ii(v1,REV));
  }
}




vector<INT> dist;
priority_queue<ii, vector<ii>, greater<ii> > pq;


void dijkstra()
{

for(int j=0;j<=V;j++) dist.push_back(INF);

dist[s] = 0;

pq.push(ii(0, s));

while (!pq.empty())
{
  ii top = pq.top(); pq.pop();
  INT d = top.first, u = top.second;
  if (d == dist[u])
  TRvii (AdjList[u], it)
  {
    INT v = it->first, weight_u_v = it->second;
    if (dist[u] + weight_u_v < dist[v])
    {
     dist[v] = dist[u] + weight_u_v;
     pq.push(ii(dist[v], v));
    }
  }
}
}

void output()
{
//  cout << "output" << endl;
//  cout << dist[s_end] << endl;
  if(dist[s_end]==INF) printf("X\n");
  else printf("%d\n",dist[s_end]/REV);
}

int main()
{
  input();
  dijkstra();
  output();
}

