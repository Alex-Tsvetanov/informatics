#include<cstdio>
#include<algorithm>
#include<utility>
#include<vector>

using namespace std;

#define pp pair<int,int>

int main()
{
    int k, k1, k2, n1, m1, n, m;
    vector<pp> ans;
    scanf("%d", &k);
    k1=2*k-1;
    k2=2*k-3;
    for(m1=3; m1*m1<=k1; m1+=2)
      if(k1%m1==0)
        ans.push_back(make_pair((m1-1)/2,(k1/m1+1)/2));
    for(n1=3; n1*n1<=k2; n1+=2)
      if(k2%n1==0) ans.push_back(make_pair((k2/n1+1)/2,(n1-1)/2));
    if (n1*(n1-2)==k2) ans.push_back(make_pair((n1-1)/2,(n1-1)/2));
    sort(ans.begin(),ans.end());
    int s=ans.size();
    printf("%d\n", s);
    for(int i=0; i<s; i++)
      printf("%d %d\n", ans[i].first, ans[i].second);
    return 0;
}
