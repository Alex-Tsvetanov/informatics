#include <iostream>
#include <vector>

using turn_t = ????; //!!!!!!!!!!!!!!!!!!!!!!!!

/*abstract*/ class player
{
private:
	int player_num; 
	std::vector <point> points;
public:
	static player (int pl_n)
	{
		player_num = pl_n;
		
	}
	virtual turn_t turn () = nullptr;
};

int main ()
{

}
