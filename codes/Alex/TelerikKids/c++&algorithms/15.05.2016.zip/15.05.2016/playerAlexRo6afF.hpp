struct AlexRo6afF : player
{

};
