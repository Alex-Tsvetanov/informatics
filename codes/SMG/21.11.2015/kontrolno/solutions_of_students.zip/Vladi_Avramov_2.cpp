#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

int main(){
int b[10];
cin >> b;
int masiv[10], masiv1[10];
len = strlen(b);
for(int i = 0 ; i < len ; i++)
return 0;
}
