#include<iostream>
using namespace std;
int main(){
long n, m;
cin>>n>>m;




return 0;
}
