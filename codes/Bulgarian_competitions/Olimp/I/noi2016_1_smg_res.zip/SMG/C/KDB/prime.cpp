#include<iostream>
using namespace std;
int main(){
long  n, p, a;
cin>>n;




return 0;
}
