#include<iostream>
using namespace std;
int main(){
long long M,N,a,b,K;
cin>>N>>M;
a=0;

while(a<N){
        b=0;
        while(b<N){
        cout<<"*";
        b++;
        }
      cout<<"\n";
      a++;
}







return 0;
}
