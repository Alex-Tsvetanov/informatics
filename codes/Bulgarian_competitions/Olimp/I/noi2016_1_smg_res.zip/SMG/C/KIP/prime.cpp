#include<iostream>
using namespace std;
int main(){


    int x;
    cin>>x;
    if(x==100101){
        cout<<"22";
    }


return 0;
}
