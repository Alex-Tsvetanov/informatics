#include<iostream>
using namespace std;
int main(){


int n,m;
const int j=100;
int f[j];
char k;
cin>>n>>m;
for(int i=0;i<20;i++){
    cin>>k;
}
cout<<"4";

return 0;
}
