#include<iostream>
using namespace std;
int main () {
long long N, M, K;
cin >> N, M;



return 0;
}
