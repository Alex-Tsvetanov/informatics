#include<iostream>
using namespace std;
int main () {
long long N;


return 0;
}
