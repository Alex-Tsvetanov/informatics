#include<iostream>
using namespace std;
int main () {
long long a,b,c,d,vhod,plosht,perimetur;
cin>>vhod;
plosht=a*b;
perimetur=a+b+c+d;
while(vhod=a,b,c,d){
            if(a==c && b==d){
cout<<"YES"<<"\n"<<plosht;
            }
    if(a!=c && b!=d){
    cout<<"NO"<<"\n"<<perimetur;
    }
}
return 0;
}
