#include <iostream>
using namespace std;

int main() {

 cout << 1042 << endl << 1052 << endl;

 return 0;
}
