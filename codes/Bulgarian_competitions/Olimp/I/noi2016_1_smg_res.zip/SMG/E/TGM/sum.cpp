#include <iostream>
using namespace std;

int main (){
    long long a,b;
    char c;
    cin >> a >> c >> b;
    cout << a+b-10 << endl;
    cout << a+b << endl;
return 0;
}
