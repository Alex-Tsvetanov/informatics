#include<iostream>
#include<cmath>
using namespace std;
int main(){
    int n;
    cin>>n;
    int x=0;
    for(x;pow(2,x)<n;x++){}

}
