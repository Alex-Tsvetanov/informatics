#include<iostream>
using namespace std;
int main(){
unsigned int N, a;
cin>> N;
while (N>0){
    cin >> a;
    N--;

}
cout << 6;
return 0;
}
