#include<iostream>
using namespace std;
int main(){
long long M,N;
cin>>M>>N;
cout<<M<<" "<<N;
cout<<endl;
cout<<M-1+N-1;
cout<<endl;
return 0;
}
