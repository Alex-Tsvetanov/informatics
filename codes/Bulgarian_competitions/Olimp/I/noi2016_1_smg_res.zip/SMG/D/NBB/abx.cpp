#include<iostream>
using namespace std;
int main(){
long long A,B,X,y;
B=A+X;
cin>>A>>B;
A>0;
B>0;
y=B-A;
cout<<y;
cout<<endl;
return 0;
}
