#include <iostream>
using namespace std;
int main (){
    long long X, B, X2=0;
    char simbol1, simbol2, A, A2;
    cin>>A>>simbol1>>X>>simbol2>>B;
    X2=B-X;
    cout<<X2;
    return 0;
}
