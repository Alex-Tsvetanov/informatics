#include<iostream>
using namespace std;
int main()
{
    int n,x;
    for(int i=0;i<5;i++)
    {
        cin>>n;
        for(int i=0;i<n;i++)
        {
            cin>>x;
        }
    }
    cout<<01101<<endl;
    return 0;
}
