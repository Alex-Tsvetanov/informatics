#include<iostream>
using namespace std;
int main ()
{
int s1,st1,lv1,s2,st2,lv2,s3,st3,lv3,a,b,y,x;
cin>>s1>>lv1>>st1;
cin>>s2>>lv2>>st2;
cin>>s3>>lv3>>st3;

if (s1>s2 && s1>s3 && lv1<lv2 && lv1<lv3)
  cout<<((a*b)/s1)*lv1+lv1<<" "<<((a*b)/s1)*st1+st1;
if (s2>s1 && s2>s3 && )
}
