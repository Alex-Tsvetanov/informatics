#include <iostream>
using namespace std;
int main () {
long long a,b;
cin >> a >> b;
cout << (a+b)-10 << endl;
cout << a+b <<endl;
return 0;
}






































