#include <iostream>
using namespace std;

int main ()
{
    int A,B;
    cin>>A>>B;

    cout<<(A+B)-10<<endl;
    cout<<A+B<<endl;

    cout<<A<<" "<<B<<endl;

    return 0;
}
