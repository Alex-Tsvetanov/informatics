#include <iostream>
using namespace std;
int main () {
 double s,lv,st,a,b;
cin >> a >> b >> lv >> st >> s;
cout << lv*(a*b/s) << endl;
cout << st/100*(a*b/s) <<endl;
return 0;
}





















