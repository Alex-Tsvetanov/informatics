#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

int main()
{
    cout << 0 << endl;
    return 0;
}
