#include<iostream>
using namespace std;
int main ()
{
   int n,m,k=1,l;
   char a,b;
   cin>>n>>m;
   for(int i=1;i<=n;i++)
   {
       cin>>a>>b;
       l=i*2;

   }
   k=m+n;
   cout<<k*(k+1)/2;
    return 0;
}
