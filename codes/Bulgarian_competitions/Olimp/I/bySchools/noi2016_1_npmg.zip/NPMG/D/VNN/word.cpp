#include <iostream>
using namespace std;

int main() {
    char A;
    long long n = 0, obroi = 0, broi[n] = 0;
    for (A = A; A != 35; A = A){
        cin >> A;
        n = A;
        if (A == n){
            broi = broi + 1;
            obroi = obroi + 1;
        }
    }
    return 0;
}
