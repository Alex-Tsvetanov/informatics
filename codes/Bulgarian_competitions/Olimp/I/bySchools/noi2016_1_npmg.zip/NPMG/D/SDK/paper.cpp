#include<iostream>
using namespace std;
int main(){
    long long m, n;
    cin>>m>>n;
    if(n==1){
        cout<<m-1;
        return 0;
    }
    cout<<7;
    return 0;
}
