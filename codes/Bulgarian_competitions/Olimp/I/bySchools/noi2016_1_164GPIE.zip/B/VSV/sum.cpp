#include <iostream>
using namespace std;
int a[100000];
int main(){
    int n,i=0,b1=0,otg=0;
    cin>>n;
    b1=n/2;
    otg=b1*2;
    cout<<otg;
    return 0;
}
