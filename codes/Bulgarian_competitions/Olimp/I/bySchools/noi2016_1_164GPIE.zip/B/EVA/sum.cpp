#include <iostream>
using namespace std;
main ()
{
	int n;
	cin >>n;
	cout <<n;
}
