#include <cmath>
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main()
{
//trans
int n;
int v=n;
int GR[v][v];
for(int i=0;i<v;i++)
{
for(int z=0;z<v;z++)
{
cout<<"input distance "<<i<<", "<<z<<endl;
cin>>GR[i][z];
}
}
int m;
int st;
cout<<"input start top "<<endl;
cin>>st;
int distanc[v],g,l,u;
m=st+1;
int min;
bool visited[v];
return 0;
}
