#include<iostream>
using namespace std;
int main () {
 long A,B,ivan,ivan1,nikol,nikol1;
 cin>>A>>B;
 cout<<endl;
nikol=A/10;
 nikol=nikol%10;

ivan=A%100;

nikol1=B/10;
 nikol1=nikol1%10;

ivan1=B%100;

if(c+c1>=10){cout<<A-10+B<<endl;}
 else{
        if(b+b1>=10){cout<<A-100+B<<endl;}
       }
 cout<<A+B<<endl;


return 0;
}






