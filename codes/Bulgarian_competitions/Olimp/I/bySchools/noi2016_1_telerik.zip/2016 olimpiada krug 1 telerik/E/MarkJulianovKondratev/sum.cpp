#include<iostream>
using namespace std ;
 int  main ()
 {long long a,b;
 cin>>a;
 cin>>b;
 cout<<a+b<<endl;
 cout<<a+b-10;
 return 0 ;
 }

