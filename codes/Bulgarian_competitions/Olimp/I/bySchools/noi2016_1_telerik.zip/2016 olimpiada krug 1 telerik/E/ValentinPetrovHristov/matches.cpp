#include<iostream>
using namespace std;
int main () {
long long a1,a2,a3,a4;
cin>>a1>>a2>>a3>>a4;
if (a1==a3){cout<<"No";}
return 0;
}

