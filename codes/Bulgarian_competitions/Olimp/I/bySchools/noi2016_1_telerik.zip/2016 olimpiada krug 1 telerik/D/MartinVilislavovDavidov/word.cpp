#include<iostream>
using namespace std;
int main(){
    char word,word_1;
    cin>>word;

    word_1=word+'#';
    if(word){
        cout<<"Ne zavurshva na'#'"<<endl;
    }


return 0;
}
