#include<iostream>
using namespace std;
int main (){
    long long M, N;
    cin>>M>>N;
    if(N==1){
    cout<<M-1;
    }
cout<<endl;
return 0;
}

