#include<iostream>
using namespace std;
int main(){
long long M,N;
cin>>M>>N;



return 0;
}
