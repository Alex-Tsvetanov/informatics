#include <iostream>
using namespace std;
int main () {
char vidBukvi,bukvi[5];
vidBukvi=bukvi[5]/'a';
cin>>bukvi[0]>>bukvi[1]>>bukvi[2]>>bukvi[3]>>bukvi[4]>>bukvi[5];
for (char bukvi[5]=0;bukvi!='#';bukvi++) {
    vidBukvi=bukvi[5]/'a';
    bukvi=bukvi[5]*'A';
    cout << bukvi;
}

}
return 0;
}
