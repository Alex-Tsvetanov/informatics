#include<iostream>
using namespace std;
int main () {
    int a ,b,r;
    char c , d , e ;
    cin  >> c >> d >> a >> e >> b ;
    if(c=='x'){
        cout << b-a;
    }else{
        r=c;
        cout << b-c;
    }
 return 0;
 }
