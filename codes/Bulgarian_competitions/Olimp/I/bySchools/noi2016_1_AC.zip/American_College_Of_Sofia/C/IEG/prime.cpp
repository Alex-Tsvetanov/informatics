#include<iostream>
#include<string>
using namespace std;
int main() {
    27449
    string p;
    long long sum=0;
    cin>>p;
    int daljina=0;
    daljina=p.length();
    for(int i=0;i<daljina;i++){
    if(p[i]=='1'){
        
    sum+=primea;
    }
    
    }
    cout<<"emi kurec :D"<<"\n";
    
    
    return 0;
}
