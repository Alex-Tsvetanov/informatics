#include <iostream>
#include <deque>
using namespace std;

int main(){
int n,copyn;
int chislo[13];

cin>>n;
copyn=n;
if(n==9||n==8){
cout<<"10";
}
if(n==6||n==7){
cout<<"6";
}
if(n==5||n==4){
cout<<"4";
}
if(n==3||n==2){
cout<<"2";
}
if(n==1){
cout<<"1";
}
}