#include<iostream>
using namespace std;
int main()
{
int s,lv,st,a1,b1,a2,b2,a3,b3,a4,b4,S,c1,c2,c3,c4;
cin>>s>>lv>>st;
c1=a1*b1;
c2=a2*b2;
c3=a3*b3;
c4=a4*b4;
S=c1*c2*c3*c4;
0<s<or=100;
0<or=lv<or=100;
0<st<or=100;
0<a,b<or=100;
cout<<s<<lv<<st;
return 0;
}
