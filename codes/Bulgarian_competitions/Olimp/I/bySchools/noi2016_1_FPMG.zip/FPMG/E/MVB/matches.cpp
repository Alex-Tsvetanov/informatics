#include<iostream>
using namespace std;
int main ()
{ int a,b,c,d,yes,no,s,p;
 cin>>a>>b>>c>>d;
 if (a=b , c=d) or(a=b=c=d); cout<<(yes);
 if (a>b , c>d) ;cout<<(no);
 if (a<b , c<d) ;cout<<(no);
 if (a=b , c>d) ;cout<<(no);
 if (a=b , c<d) ;cout<<(no);
 if (a<b , c=d) ;cout<<(no);
 if (a>b , c=d) ;cout<<(no);
 if (no) : cout<<(a+b+c+d);
 if (yes): cout<,a*c or a*d or b*c or b*d;
 cout<<(yes) or no<" "<p or s;










    return 0;
}
