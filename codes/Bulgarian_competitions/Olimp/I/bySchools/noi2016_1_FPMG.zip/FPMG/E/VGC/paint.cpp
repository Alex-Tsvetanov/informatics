#include<iostream>
using namespace std;
int main ()
{
int st,a,b,s,lv;
0<s<100;
0<lv<100;
0<st<100;
0<a,b<25;
cin>>a;
cout<<s<<st<<lv;

     return 0;

}

