#include<iostream>
using namespace std;
int main ()
{
int a,b,c,v;
cin>>a>>b;
if (c=1042);
if (v=1052);
if (128+924==1042) cout<<v<<endl;
if (128+924==1052) cout<<c<<endl;
if (128+924==1042) cout<<c<<endl;
if (128+924==1052) cout<<v<<endl;



    return 0;
}
