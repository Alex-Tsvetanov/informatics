#include<iostream>
using namespace std;
int main ()
{
int a,b,x,z,y,f,m,n;
std::cin>>(a+b);
a=x*1+y*10+z*100;
b=f*1+m*10+n*100;
cout<<x*1+(y*10-1)+z*100<" "<x*1+y*10+z*100;












    return 0;
}
