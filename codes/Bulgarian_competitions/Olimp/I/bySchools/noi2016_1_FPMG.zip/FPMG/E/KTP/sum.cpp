#include<iostream>
using namespace std;
int main()
{
char A;
char B;
cin>>A>>B;
if(A+B=1042)=false;
if(A+B=1052)=true;
100<or=A,B<or=999;
cout<<false,true;
retrn 0;
}

