#include<iostream>
using namespace std;
int main()
{
    int a,b,c,d;
    cin>>a>>b;
    c=a+b;
    d=a-5+b-5;
    cout<<d<<endl;
    cout<<c;
    return 0;
}
