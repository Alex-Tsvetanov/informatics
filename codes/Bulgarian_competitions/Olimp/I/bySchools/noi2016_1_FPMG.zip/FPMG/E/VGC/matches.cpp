#include<iostream>
using namespace std;
int main ()
{
int a,b,c,d,r,s,t,y,u,f;
cin>>a>>b>>c>>d;
if (r=1)
if (d=1)
if (c=1)
if (b=1)
if (a=1)
if (a+b+c+d==1) cout<<"YES"<<endl;
if (a+b+c+d==1) cout<<1<<endl;

if (s=10)
if (t=1)
if (y=2)
if (u=3)
if (f=4)
if (t+y+u+f==10) cout<<"NO"<<endl;
if (t+y+u+f==10) cout<<10<<endl;

   return 0;
}





