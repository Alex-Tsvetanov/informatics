#include<iostream>
using namespace std;
int main()
{
    int a,d,g,v;
    cin>>a>>d;
    v=a+d;
    g=(a+d)-10;
    cout<<g<<"\n"<<v;
    return 0;
}

