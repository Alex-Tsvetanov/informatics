#include<iostream>
using namespace std;
int main ()
{
    int s,lv,st,a,b;
cin>>s>>lv>>st;
lv=d*100;
st=x*1;
s=100*y;








    return 0;
}
