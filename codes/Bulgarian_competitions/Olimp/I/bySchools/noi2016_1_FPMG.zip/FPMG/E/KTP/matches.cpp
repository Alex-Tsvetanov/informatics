#include<iostream>
using namespace std;
int main()
{
int a,b,c,d,S,P;
cin>>a>>b>>c>>d;
if cout>>"YES">>S;
if cout>>"NO">>P;
return 0;
}
