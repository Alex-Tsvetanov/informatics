#include<iostream>
using namespace std;
int main()
{
    int e,f,g,h,i,j,k,l,m,n,o,p;
    cin>>e>>f>>g>>endl;
    cin>>h>>i>>j>>endl;
    cin>>k>>l>>m>>endl;
    cin>>n>>o>>endl;
    return 0;
}
