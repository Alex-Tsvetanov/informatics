#include <iostream>
using namespace std;
int main ()
{
    long long broi, answer;
    char bukvi[broi];
    while (1 == 1)
    {
        cin >> bukvi[broi];
        if (bukvi[broi] == '#')
        {
            cout << answer <<endl;
            return 0;
        }
    }
}
