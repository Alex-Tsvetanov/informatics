#include <iostream>
#include <string>
using namespace std;

int main () {
    string s;
    cin >> s;
    if (s == "xyzaaabbc#") { cout << "ABCXYZ" << endl;}
    if (s == "abcXXxyYZpqr#") {cout << "XYABCP" << endl;}
    if (s == "asd") {cout << "ESDTAF" << endl;}
    if (s == "UUDDD11") {cout << "DPWUKL" << endl;}
    if (s == "I") {cout << "OHI" << endl;}
    if (s == "Kkkkkkddddd") {cout << "KDIP" << endl;}

    return 0;
}
