#include<iostream>
using namespace std;
int main () {
long long suma,A,B,cifra,smqtane;
cin>>smqtane;
suma=A+B;
A<=999;
B<=999;
while(smqtane=A+B){
cout<<suma;
}
return 0;
}
