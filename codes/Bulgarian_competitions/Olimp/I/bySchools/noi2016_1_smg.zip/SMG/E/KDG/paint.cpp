#include<iostream>
using namespace std;
int main () {
long long plosht,lv,st,dulzina,shirina,naiNiskaCena,ploshtKutiqBoq,cenaZaKutiq,broiKutii;
cin>>plosht;
ploshtKutiqBoq=3,4,5;
plosht=(shirina*dulzina)*4;
if(plosht=(shirina*dulzina)*4){
        broiKutii*cenaZaKutiq==naiNiskaCena;
     cin>>plosht;
     cout<<naiNiskaCena;
     }
return 0;
}
