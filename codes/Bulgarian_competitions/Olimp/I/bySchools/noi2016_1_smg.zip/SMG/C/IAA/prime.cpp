#include<iostream>
using namespace std;
int main(){
long long a,b,c;
char N[3000];
cin>>N;











return 0;
}
