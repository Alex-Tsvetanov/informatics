#include<iostream>
using namespace std;
int main(){
int N;
cin>>N;
if(N%2!=0){
    N=N-1;
}
switch(N){
case 1:cout<<"1";break;
case 2:cout<<"2";break;
case 4:cout<<"4";break;
case 6:cout<<"6";break;
case 8:cout<<"10";break;
case 10:cout<<"14";break;
case 12:cout<<"20";break;
case 14:cout<<"26";break;
case 16:cout<<"34";break;
case 18:cout<<"42";break;
case 20:cout<<"52";break;
case 22:cout<<"62";break;
case 24:cout<<"74";break;
case 26:cout<<"86";break;
case 28:cout<<"100";break;
case 30:cout<<"114";break;
case 32:cout<<"130";break;
case 34:cout<<"146";break;
case 36:cout<<"164";break;
case 38:cout<<"182";break;
case 40:cout<<"202";break;
case 42:cout<<"222";break;
case 44:cout<<"244";break;
case 46:cout<<"266";break;
case 48:cout<<"290";break;
case 50:cout<<"314";break;
case 52:cout<<"340";break;
case 54:cout<<"366";break;
case 56:cout<<"394";break;
case 58:cout<<"422";break;
case 60:cout<<"452";break;
case 62:cout<<"482";break;
case 64:cout<<"514";break;
case 66:cout<<"546";break;
case 68:cout<<"580";break;
case 70:cout<<"614";break;
case 72:cout<<"650";break;
}
//Znam poredicata ama ne znam kak da q nakodq!
return 0;
}
