#include<iostream>
using namespace std;
int main()
{
    int cx,xy,ax1,ay1,ax2,ay2;
    cin>>cx>>cy>>ax1>>ay1>>ax2>>ay2

    return 0;
}
