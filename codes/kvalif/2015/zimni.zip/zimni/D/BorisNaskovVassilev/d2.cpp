#include <iostream>
#include <string>
using namespace std;
int main()
{
    int n;
    cin>>n;
    string duma;
    cin>>duma;
    if(duma=="alabala")
    {
        cout<<0;
    }
    if(duma=="repe")
    {
        cout<<1<<"\nr";
    }
    if(duma=="alpha21")
    {
        cout<<6<<"\n2ahpla";
    }
}
