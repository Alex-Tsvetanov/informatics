#include<iostream>
using namespace std;
int main() {
    long long a, b, c;
    cin>>a>>b;
    c=0;
    cout<<c;
    cout<<endl;
    return 0;
}
