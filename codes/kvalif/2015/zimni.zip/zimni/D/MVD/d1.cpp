#include<iostream>
using namespace std;
int main(){
int n,t[20];
cin>>t[0]>>t[1]>>t[2]>>n;
return 0;
}
