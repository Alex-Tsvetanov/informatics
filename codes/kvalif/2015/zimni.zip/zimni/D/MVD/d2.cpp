#include<iostream>
using namespace std;
int main(){
    int n,m=0;
    string str;
    cin>>n;
    cin>>str;
    if(str[0]==str[n-1]){
        cout<<'0'<<endl;
    }
return 0;
}
