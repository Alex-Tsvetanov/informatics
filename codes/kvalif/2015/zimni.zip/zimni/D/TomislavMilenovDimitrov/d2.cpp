#include<iostream>
using namespace std;
int main(){
long long n,m=0,i,i2,i3;
char a[2100];
bool s=0;
cin>>n>>a;
cout<<"1"<<endl<<a[0]<<endl;
return 0;
}
