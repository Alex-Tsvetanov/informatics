#include <iostream>
using namespace std;

int main()
{
    long long a,b,c,d;
    cin >> a >> b >> c >> d ;
    cout << c+d-(b+a) << endl;

    return 0;
}
