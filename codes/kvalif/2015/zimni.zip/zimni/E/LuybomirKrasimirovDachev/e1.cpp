#include<iostream>
using namespace std;
int main()
{
    int x,y,d,p,a,b,cb,a2,b2;
    cin>>x>>y;
    cin>>d;
    cb=a+b;
    p=x*100+y;
    cb=p/2-d;
    a=cb/2+d;
    b=cb/2;
    cout<<a<<endl;
    cout<<b<<endl;
    return 0;
}
