#include <iostream>
using namespace std;
int main () {
 double xy;
 double d;
cin>>xy;
cin>>d;
cout<<xy/4+0.d<<endl;
cout<<xy/4-0.d<<endl;
return 0;
}
