#include <iostream>
using namespace std;
int main () {
long long T1,T2,T3,N;
cin>>T1>>T2>>T3>>N;
cout<<T3+T2+T1<<endl;
return 0;
}
