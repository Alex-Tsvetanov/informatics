#include<iostream>
using namespace std;
int main(){
int a,b,x,y,d;
cin>>x>>y>>d;
cout<<a<<b;
return 0;
}
