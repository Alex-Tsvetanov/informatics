#include <iostream>
using namespace std;
int main()
{
long long
cin>>








cout<<endl;
return 0;
}
