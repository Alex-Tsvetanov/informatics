#include <iostream>
using namespace std;
int main ()
{
int t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,N;
cin>>t1 >>t2 >>t3 >>N;


if (N==1) {
cout<<t1<<endl;
}
if (N==2){
cout<<t2<<endl;
}
if (N==3){
cout<<t3<<endl;
}
if (N==4){
cout<<t4<<endl;
}
if (N==5){
cout<<t5<<endl;
}
if (N==6){
cout<<t6<<endl;
}
if (N==7){
cout<<t7<<endl;
}
if (N==8){
cout<<t8<<endl;
}
if (N==9){
cout<<t9<<endl;
}
if (N==10){
cout<<t10<<endl;
}
if (N==11){
cout<<t11<<endl;
}
if (N==12){
cout<<t12<<endl;
}
if (N==13){
cout<<t13<<endl;
}
if (N==14){
cout<<t14<<endl;
}
if (N==15){
cout<<t15<<endl;
}
if (N==16){
cout<<t16<<endl;
}
if (N==17){
cout<<t17<<endl;
}
if (N==18){
cout<<t18<<endl;
}
if (N==19){
cout<<t19<<endl;
}
if (N==20){
cout<<t20<<endl;
}

t4=t3+t2+t1;
t5=t4+t3+t2;
t6=t5+t4+t3;
t7=t6+t5+t4;
t8=t7+t6+t5;
t9=t8+t7+t6;
t10=t9+t8+t7;
t11=t10+t9+t8;
t12=t11+t10+t9;
t13=t12+t11+t10;
t14=t13+t12+t11;
t15=t14+t13+t12;
t16=t15+t14+t13;
t17=t16+t15+t14;
t18=t17+t16+t15;
t19=t18+t17+t16;
t20=t19+t18+t17;


return 0;
}

















