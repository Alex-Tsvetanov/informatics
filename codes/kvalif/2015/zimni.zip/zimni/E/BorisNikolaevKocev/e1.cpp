#include<iostream>
using namespace std;
int main()
{
long long  d,a,b,p;
cin>>d>>b;
a=b+d;
p=2*a+2*b;
cout<<a<<endl;
cout<<b<<endl;
cout<<p<<endl;
return 0;
}
