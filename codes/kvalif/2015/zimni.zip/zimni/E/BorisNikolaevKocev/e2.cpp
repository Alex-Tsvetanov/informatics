#include<iostream>
using namespace std;
int main()
{
long long T1,T2,T3,N,T4,T,TN;
cin>>T1>>T2>>T3;
N=T1+T2+T3;
T1=T2+T3+T4;
T=T1+T2+T3;
cout<<TN;
return 0;
}
