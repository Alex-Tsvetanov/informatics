#include<iostream>
using namespace std;
int main ()
{ int x,y,d,a,b,P,m,f,h,sm,n,k,l,o;
  cin>>a>>b>>d;
  m=f*1;
  sm=h*100;
  n=l*1;
  k=o*100;
  a=m+sm;
  b=n+k;
  a=b+d;
  a>b;
  P=2*a+2*b;
  P=x*100+y;
  a=(P%2)-(70+b);
  b=(P%2)-(70+b+d);
  cout<<a<<" "<<b;


    return 0;
}
