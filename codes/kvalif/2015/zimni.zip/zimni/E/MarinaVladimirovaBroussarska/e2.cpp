#include<iostream>
using namespace std;
int main ()
{ int N,T1,T2,T3,T,Tn;
  cin>>T1>>T2>>T3;
  T=T1+T2+T3;
  cout<<T;

    return 0;
}
