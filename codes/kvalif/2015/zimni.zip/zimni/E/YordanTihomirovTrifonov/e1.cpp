#include <iostream>
using namespace std ;
int main ()

{

    long long x,y,d;
    cin>>x,y;
    cin>>d;
    d=d+0;
    if(x%4==0) {
        cout<<x/4+d<<""<<x/4+y/4+d<<endl;
        cout<<x/4+d<<""<<x/4+y/4-d<<endl;
    }
        if(x%4!=0) {
        cout<<(x-1)/4+d<<""<<(y+100)
        cout<<(x-1)/4+d<<""<<(y+100)



        }

























   return 0 ;

}
