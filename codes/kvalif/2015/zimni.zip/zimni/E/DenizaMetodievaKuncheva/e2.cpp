#include <iostream>
using namespace std;

int main()
{
    int tn,t1,t2,t3,n;
    cin>>t1,t2,t3,n;

    tn=t1+t2+t3;
    n=tn;


    cout<<n<<endl;
    return 0;
}
