#include <iostream>
using namespace std;
int main (){
int N,M,T;
cin>>N>>M>>T;
int x1,y1,x2,y2;
cin>>x1>>y1>>x2>>y2;
y1=y1-1;
x1=x1-1;
y2=y2-1;
x2=x2-1;
int bolni =2;
int matrix[N][M];
matrix[y1][x1]=1;
matrix[y2][x2]=1;
for(int i =0;i<T;i++){
}


}
